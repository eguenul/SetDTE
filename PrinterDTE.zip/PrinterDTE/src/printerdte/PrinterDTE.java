/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package printerdte;

/**
 *
 * @author esteban
 */
public class PrinterDTE {

    /**
     * @param args the command line arguments
     * @throws java.lang.Exception
     */
    public static void main(String[] args) throws Exception {
        // TO  Config objConfig = new Config();
           /* String nombredte = args[0];*/
            String rango_inicio = args[0];
            String rango_final = args[1];
            String numresol = args[2];
            PrintDTE objprint = new PrintDTE();
          
            for(int i=Integer.parseInt(rango_inicio); i<=Integer.parseInt(rango_final); i++){

                objprint.printDTE("DTE"+String.valueOf(i), numresol);
            }
    
   
     }
    
}
