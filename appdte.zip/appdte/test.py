from suds.client import Client
client = Client(url='http://localhost:8080/APPDTEWS/sendDTEWS?wsdl')
fichero = open('/home/esteban/appdte/JSON/DTEPRUEBA.json')
lineas = fichero.readlines()
cadena = ""
for linea in lineas: 
    cadena = cadena + linea
print(cadena)
respuesta = client.service.sendDTE(cadena,"carlosaguilar","Chile2022","25880815-0")
print(respuesta)
